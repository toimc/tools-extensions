export function run() {
  console.log('extension 1');
}
